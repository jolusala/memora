/* ============ CLIENTE API ============ */
async function api(url, opts = {}) {
  const res = await fetch(url, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    credentials: 'include',
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  let data = null;
  try { data = await res.json(); } catch (e) { /* respuesta sin cuerpo */ }
  if (!res.ok) throw new Error((data && data.error) || ('Error ' + res.status));
  return data;
}

async function apiUpload(url, formData) {
  const res = await fetch(url, { method: 'POST', credentials: 'include', body: formData });
  let data = null;
  try { data = await res.json(); } catch (e) { /* respuesta sin cuerpo */ }
  if (!res.ok) throw new Error((data && data.error) || ('Error ' + res.status));
  return data;
}

/* ============ DATOS / ESTADO ============ */
const LAYOUTS = {
  single: { label: '1 foto', slots: 1, cls: 'layout-single' },
  duoH: { label: '2 fotos', slots: 2, cls: 'layout-duoH' },
  duoV: { label: '2 fotos', slots: 2, cls: 'layout-duoV' },
  trio: { label: '3 fotos', slots: 3, cls: 'layout-trio' },
  quad: { label: '4 fotos', slots: 4, cls: 'layout-quad' },
};
function svgUri(svg) { return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg); }

/* Ilustraciones planas de ejemplo (no fotos reales) para mostrar el estilo de cada plantilla */
const SAMPLE_ART = {
  coast: svgUri(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><linearGradient id='g1' x1='0' y1='0' x2='0' y2='1'><stop stop-color='#e69a6b'/><stop offset='1' stop-color='#f4c89a'/></linearGradient></defs><rect width='400' height='400' fill='url(#g1)'/><circle cx='320' cy='80' r='38' fill='#fbe8c8' opacity='.95'/><path d='M0 250 Q90 210 180 240 T400 225 V400 H0Z' fill='#a75c42' opacity='.8'/><path d='M0 300 Q120 260 230 290 T400 275 V400 H0Z' fill='#6f4a3a' opacity='.5'/><g fill='#fff6e8' opacity='.92'><rect x='60' y='190' width='42' height='70' rx='2'/><rect x='112' y='170' width='52' height='90' rx='2'/><rect x='176' y='200' width='36' height='60' rx='2'/></g></svg>`),
  minimal: svgUri(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><rect width='400' height='400' fill='#f3ece1'/><rect x='70' y='90' width='190' height='240' rx='6' fill='#e3d3bd'/><circle cx='305' cy='300' r='55' fill='#cf6e4a' opacity='.35'/><line x1='40' y1='40' x2='140' y2='40' stroke='#a94f31' stroke-width='4'/></svg>`),
  warmth: svgUri(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><linearGradient id='g2' x1='0' y1='0' x2='1' y2='1'><stop stop-color='#d98a7a'/><stop offset='1' stop-color='#efc3ab'/></linearGradient></defs><rect width='400' height='400' fill='url(#g2)'/><circle cx='160' cy='210' r='95' fill='#fff2e4' opacity='.55'/><circle cx='250' cy='210' r='95' fill='#fff2e4' opacity='.55'/><circle cx='205' cy='150' r='14' fill='#a94f31' opacity='.6'/></svg>`),
  shore: svgUri(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><linearGradient id='g3' x1='0' y1='0' x2='0' y2='1'><stop stop-color='#6f9c9a'/><stop offset='1' stop-color='#bcd8cf'/></linearGradient></defs><rect width='400' height='400' fill='url(#g3)'/><circle cx='330' cy='70' r='34' fill='#fbe8c8'/><path d='M0 260 Q100 230 200 255 T400 240 V400 H0Z' fill='#fff' opacity='.85'/><path d='M0 300 Q120 280 240 300 T400 290 V400 H0Z' fill='#e7ddc9' opacity='.9'/></svg>`),
  roots: svgUri(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><defs><linearGradient id='g4' x1='0' y1='0' x2='0' y2='1'><stop stop-color='#93a884'/><stop offset='1' stop-color='#c9d3b8'/></linearGradient></defs><rect width='400' height='400' fill='url(#g4)'/><path d='M0 270 Q100 220 200 260 T400 240 V400 H0Z' fill='#5c6e52' opacity='.55'/><circle cx='90' cy='110' r='30' fill='#fff6e8' opacity='.85'/></svg>`),
};

const TEMPLATES = [
  { id: 'editorial', name: 'Editorial', desc: 'Historias de viaje con aire de revista', defaultLayout: 'trio', badge: 'Popular', art: ['coast', 'roots', 'shore'] },
  { id: 'minimal', name: 'Minimal', desc: 'Mucho espacio, la foto es protagonista', defaultLayout: 'single', badge: 'Nuevo', art: ['minimal'] },
  { id: 'memories', name: 'Memories', desc: 'Cálido, emocional y personal', defaultLayout: 'duoV', badge: '', art: ['warmth', 'roots'] },
  { id: 'postcards', name: 'Postcards', desc: 'Perfecto para escapadas', defaultLayout: 'duoH', badge: '', art: ['shore', 'coast'] },
];

let seq = 1;
const uid = (p) => p + (seq++);

let state = {
  user: null,
  authMode: 'login',
  authError: '',
  screen: 'home',
  photobooks: [],
  selectedBookId: null,
  previewPage: 0,
  profile: { highQuality: true },
  draft: null,
  editingBookId: null,
  createStep: 1,
  armedSlot: null,
  search: '',
  lightbox: null,
};

function newPage(layoutKey) {
  const l = LAYOUTS[layoutKey] || LAYOUTS.single;
  return { id: uid('pg'), layout: layoutKey in LAYOUTS ? layoutKey : 'single', slots: new Array(l.slots).fill(null) };
}

function newDraft(templateId) {
  const tpl = TEMPLATES.find(t => t.id === templateId) || TEMPLATES[0];
  return {
    title: 'Mi viaje inolvidable', place: '', year: String(new Date().getFullYear()),
    description: '', template: tpl.id, photos: [], pages: [newPage(tpl.defaultLayout)],
    _removedPhotoIds: [],
  };
}

function startCreate(templateId) {
  state.draft = newDraft(templateId);
  state.editingBookId = null;
  state.createStep = 1;
  state.armedSlot = null;
  state.screen = 'create';
  render();
}

function startEdit(bookId) {
  const book = state.photobooks.find(b => b.id === bookId);
  if (!book) return;
  state.draft = JSON.parse(JSON.stringify(book));
  state.draft._removedPhotoIds = [];
  state.editingBookId = bookId;
  state.createStep = 1;
  state.armedSlot = null;
  state.screen = 'create';
  render();
}

function removeDraftPhoto(photoId) {
  const d = state.draft;
  const photo = d.photos.find(p => p.id === photoId);
  if (photo && !photo.file) {
    d._removedPhotoIds = d._removedPhotoIds || [];
    d._removedPhotoIds.push(photoId);
  }
  d.photos = d.photos.filter(x => x.id !== photoId);
  d.pages.forEach(pg => pg.slots = pg.slots.map(s => s === photoId ? null : s));
}

async function saveDraft(btn) {
  const d = state.draft;
  if (!d.title.trim()) d.title = 'Mi photobook';
  if (btn) { btn.disabled = true; btn.textContent = 'Guardando…'; }

  try {
    let bookId = state.editingBookId;

    if (!bookId) {
      const { book } = await api('/api/books', {
        method: 'POST',
        body: { title: d.title, place: d.place, year: d.year, description: d.description, template: d.template, pages: [] },
      });
      bookId = book.id;
    } else {
      for (const pid of (d._removedPhotoIds || [])) {
        await api(`/api/books/${bookId}/photos/${pid}`, { method: 'DELETE' });
      }
    }

    const idMap = {};
    for (const photo of d.photos) {
      if (photo.file) {
        const form = new FormData();
        form.append('photo', photo.file);
        const { photo: uploaded } = await apiUpload(`/api/books/${bookId}/photos`, form);
        idMap[photo.id] = uploaded.id;
        photo.id = uploaded.id;
        photo.url = uploaded.url;
        delete photo.file;
      }
    }
    const finalPages = d.pages.map(pg => ({
      ...pg,
      slots: pg.slots.map(sid => (sid && idMap[sid] !== undefined) ? idMap[sid] : sid),
    }));

    const { book: saved } = await api(`/api/books/${bookId}`, {
      method: 'PUT',
      body: { title: d.title, place: d.place, year: d.year, description: d.description, template: d.template, pages: finalPages },
    });

    const idx = state.photobooks.findIndex(b => b.id === bookId);
    if (idx >= 0) state.photobooks[idx] = saved; else state.photobooks.unshift(saved);
    state.selectedBookId = bookId;
    state.draft = null;
    state.editingBookId = null;
    state.screen = 'album';
    toast('Photobook guardado ✓');
  } catch (err) {
    console.error(err);
    showMessage('No se pudo guardar el photobook.\n\nDetalle: ' + (err && err.message ? err.message : err));
  } finally {
    render();
  }
}

async function deleteBook(bookId) {
  if (!confirm('¿Eliminar este photobook? Esta acción no se puede deshacer.')) return;
  try {
    await api(`/api/books/${bookId}`, { method: 'DELETE' });
    state.photobooks = state.photobooks.filter(b => b.id !== bookId);
    state.screen = 'library';
  } catch (err) {
    showMessage('No se pudo eliminar el photobook.\n\nDetalle: ' + (err && err.message ? err.message : err));
  } finally {
    render();
  }
}

function toast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2400);
}

function showMessage(text) {
  const backdrop = document.createElement('div');
  backdrop.className = 'modal-backdrop';
  backdrop.style.zIndex = '100';
  const box = document.createElement('div');
  box.style.cssText = 'background:var(--paper);border-radius:18px;padding:28px;max-width:440px;box-shadow:0 30px 70px rgba(0,0,0,.28);';
  box.innerHTML = `<p style="margin:0 0 18px;line-height:1.6;white-space:pre-wrap;">${text}</p>`;
  const btn = document.createElement('button');
  btn.className = 'primary-button';
  btn.textContent = 'Entendido';
  btn.addEventListener('click', () => backdrop.remove());
  box.appendChild(btn);
  backdrop.appendChild(box);
  backdrop.addEventListener('click', e => { if (e.target === backdrop) backdrop.remove(); });
  document.body.appendChild(backdrop);
}

function allRecentPhotos(limit) {
  const out = [];
  state.photobooks.forEach(b => {
    b.photos.forEach(p => out.push({ ...p, bookTitle: b.title }));
  });
  return out.slice(-limit).reverse();
}

/* ============ HELPERS DE ARCHIVOS ============ */
function readFilesToDraft(fileList) {
  const files = [...fileList].filter(f => f.type.startsWith('image/'));
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = ev => {
      state.draft.photos.push({ id: uid('ph'), url: ev.target.result, file });
      render();
    };
    reader.readAsDataURL(file);
  });
}

/* ============ SESIÓN ============ */
async function loadBooks() {
  try {
    const { books } = await api('/api/books');
    state.photobooks = books;
  } catch (err) {
    console.error(err);
    state.photobooks = [];
  }
}

async function boot() {
  try {
    const { user } = await api('/api/auth/me');
    state.user = user;
    await loadBooks();
  } catch (e) {
    state.user = null;
  }
  render();
}

async function logout() {
  try { await api('/api/auth/logout', { method: 'POST' }); } catch (e) { /* seguimos igual */ }
  state.user = null;
  state.photobooks = [];
  state.selectedBookId = null;
  state.screen = 'home';
  render();
}

/* ============ RENDER RAÍZ ============ */
function render() {
  const root = document.getElementById('root');
  root.innerHTML = '';
  if (!state.user) {
    root.appendChild(AuthScreen());
    return;
  }
  root.appendChild(buildShell());
  if (state.lightbox) root.appendChild(buildLightbox());
}

function el(tag, cls, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html !== undefined) e.innerHTML = html;
  return e;
}

/* ============ ACCESO (login / registro) ============ */
function AuthScreen() {
  const shell = el('div', 'auth-shell');
  const card = el('div', 'auth-card');
  card.appendChild(el('div', 'auth-brand', '<span class="brand-mark">◆</span><span>memora</span>'));

  const tabs = el('div', 'auth-tabs');
  const loginTab = el('button', state.authMode === 'login' ? 'active' : '', 'Iniciar sesión');
  const registerTab = el('button', state.authMode === 'register' ? 'active' : '', 'Crear cuenta');
  loginTab.type = 'button'; registerTab.type = 'button';
  loginTab.addEventListener('click', () => { state.authMode = 'login'; state.authError = ''; render(); });
  registerTab.addEventListener('click', () => { state.authMode = 'register'; state.authError = ''; render(); });
  tabs.appendChild(loginTab); tabs.appendChild(registerTab);
  card.appendChild(tabs);

  if (state.authError) card.appendChild(el('div', 'auth-error', state.authError));

  const form = document.createElement('form');
  form.className = 'auth-form';

  let nameInput = null;
  if (state.authMode === 'register') {
    const nameGroup = el('div', 'field-group');
    nameGroup.appendChild(el('label', null, 'Nombre'));
    nameInput = document.createElement('input');
    nameInput.placeholder = 'Tu nombre';
    nameGroup.appendChild(nameInput);
    form.appendChild(nameGroup);
  }

  const emailGroup = el('div', 'field-group');
  emailGroup.appendChild(el('label', null, 'Email'));
  const emailInput = document.createElement('input');
  emailInput.type = 'email'; emailInput.required = true; emailInput.autocomplete = 'email';
  emailGroup.appendChild(emailInput);
  form.appendChild(emailGroup);

  const passGroup = el('div', 'field-group');
  passGroup.appendChild(el('label', null, 'Contraseña'));
  const passInput = document.createElement('input');
  passInput.type = 'password'; passInput.required = true; passInput.minLength = 6;
  passInput.autocomplete = state.authMode === 'register' ? 'new-password' : 'current-password';
  passGroup.appendChild(passInput);
  form.appendChild(passGroup);

  const submitBtn = el('button', 'primary-button', state.authMode === 'login' ? 'Iniciar sesión' : 'Crear cuenta');
  submitBtn.type = 'submit';
  submitBtn.style.width = '100%';
  submitBtn.style.justifyContent = 'center';
  form.appendChild(submitBtn);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    const original = submitBtn.textContent;
    submitBtn.textContent = 'Un momento…';
    try {
      const payload = { email: emailInput.value.trim(), password: passInput.value };
      if (state.authMode === 'register') payload.name = nameInput.value.trim();
      const endpoint = state.authMode === 'register' ? '/api/auth/register' : '/api/auth/login';
      const { user } = await api(endpoint, { method: 'POST', body: payload });
      state.user = user;
      state.authError = '';
      await loadBooks();
      render();
    } catch (err) {
      state.authError = err.message || 'Ocurrió un error';
      submitBtn.disabled = false;
      submitBtn.textContent = original;
      render();
    }
  });
  card.appendChild(form);

  card.appendChild(el('div', 'auth-divider', 'o'));
  const googleBtn = el('a', 'secondary-button auth-google', 'Continuar con Google');
  googleBtn.href = '/api/auth/google';
  card.appendChild(googleBtn);

  const switchLine = el('div', 'auth-switch');
  if (state.authMode === 'login') {
    switchLine.appendChild(document.createTextNode('¿No tienes cuenta? '));
    const link = el('button', null, 'Crear una'); link.type = 'button';
    link.addEventListener('click', () => { state.authMode = 'register'; state.authError = ''; render(); });
    switchLine.appendChild(link);
  } else {
    switchLine.appendChild(document.createTextNode('¿Ya tienes cuenta? '));
    const link = el('button', null, 'Iniciar sesión'); link.type = 'button';
    link.addEventListener('click', () => { state.authMode = 'login'; state.authError = ''; render(); });
    switchLine.appendChild(link);
  }
  card.appendChild(switchLine);

  shell.appendChild(card);
  return shell;
}

function buildShell() {
  const shell = el('div', 'app-shell');
  shell.appendChild(buildSidebar());
  const main = el('main', 'main-area');
  main.appendChild(buildTopbar());
  const content = el('section', 'content-area');
  content.appendChild(buildScreen());
  main.appendChild(content);
  shell.appendChild(main);
  return shell;
}

function buildSidebar() {
  const nav = [
    { id: 'home', label: 'Inicio', icon: '⌂' },
    { id: 'library', label: 'Mis photobooks', icon: '▤' },
    { id: 'create', label: 'Crear nuevo', icon: '+' },
    { id: 'templates', label: 'Plantillas', icon: '▦' },
  ];
  const aside = el('aside', 'sidebar');
  const brand = el('button', 'brand', '<span class="brand-mark">◆</span><span>memora</span>');
  brand.addEventListener('click', () => { state.screen = 'home'; render(); });
  aside.appendChild(brand);

  const navWrap = el('nav', 'side-nav');
  nav.forEach(item => {
    const active = state.screen === item.id || (state.screen === 'album' && item.id === 'library') || (state.screen === 'preview' && item.id === 'library');
    const btn = el('button', 'nav-item' + (active ? ' active' : ''), `<span>${item.icon}</span><span>${item.label}</span>`);
    btn.addEventListener('click', () => {
      if (item.id === 'create') startCreate(TEMPLATES[0].id);
      else { state.screen = item.id; render(); }
    });
    navWrap.appendChild(btn);
  });
  aside.appendChild(navWrap);
  aside.appendChild(el('div', 'sidebar-spacer'));

  const totalPhotos = state.photobooks.reduce((s, b) => s + b.photos.length, 0);
  const storage = el('div', 'storage-card', `
    <div class="storage-top"><span>Tu colección</span><span>${state.photobooks.length}</span></div>
    <p>${state.photobooks.length} photobook${state.photobooks.length === 1 ? '' : 's'} · ${totalPhotos} foto${totalPhotos === 1 ? '' : 's'}</p>
  `);
  aside.appendChild(storage);

  const displayName = (state.user.name || state.user.email.split('@')[0]);
  const initials = displayName.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase() || '?';
  const profileBtn = el('button', 'profile-card', `
    <span class="avatar">${initials}</span>
    <span class="profile-copy"><strong>${displayName}</strong><small>${state.user.email}</small></span>
    <span>⋯</span>
  `);
  profileBtn.addEventListener('click', () => { state.screen = 'profile'; render(); });
  aside.appendChild(profileBtn);
  return aside;
}

function buildTopbar() {
  const bar = el('header', 'topbar');
  bar.appendChild(el('div', 'mobile-brand', '<span class="brand-mark">◆</span><strong>memora</strong>'));
  const actions = el('div', 'topbar-actions');
  const searchBtn = el('button', 'icon-button', '⌕');
  searchBtn.title = 'Buscar en tus photobooks';
  searchBtn.addEventListener('click', () => { state.screen = 'library'; render(); });
  const settingsBtn = el('button', 'icon-button', '⚙');
  settingsBtn.addEventListener('click', () => { state.screen = 'profile'; render(); });
  const newBtn = el('button', 'primary-small', '+ Nuevo photobook');
  newBtn.addEventListener('click', () => startCreate(TEMPLATES[0].id));
  actions.appendChild(searchBtn); actions.appendChild(settingsBtn); actions.appendChild(newBtn);
  bar.appendChild(actions);
  return bar;
}

function buildScreen() {
  switch (state.screen) {
    case 'home': return HomeScreen();
    case 'library': return LibraryScreen();
    case 'create': return CreateScreen();
    case 'templates': return TemplatesScreen();
    case 'album': return AlbumScreen();
    case 'preview': return PreviewScreen();
    case 'profile': return ProfileScreen();
    default: return HomeScreen();
  }
}

/* ============ INICIO ============ */
function HomeScreen() {
  const wrap = el('div', 'screen-stack');
  const latest = state.photobooks[0];

  const hero = el('section', 'hero-card');
  const copy = el('div', 'hero-copy', `
    <span class="eyebrow">✦ Tus historias merecen quedarse</span>
    <h1>Convierte tus fotos en recuerdos que puedas volver a vivir.</h1>
    <p>Diseña photobooks digitales, organiza momentos y expórtalos en PDF listos para compartir o imprimir.</p>
  `);
  const actions = el('div', 'hero-actions');
  const createBtn = el('button', 'primary-button', 'Crear mi photobook →');
  createBtn.addEventListener('click', () => startCreate(TEMPLATES[0].id));
  const tplBtn = el('button', 'secondary-button', 'Explorar plantillas');
  tplBtn.addEventListener('click', () => { state.screen = 'templates'; render(); });
  actions.appendChild(createBtn); actions.appendChild(tplBtn);
  copy.appendChild(actions);
  hero.appendChild(copy);

  const visual = el('div', 'hero-visual');
  visual.setAttribute('aria-hidden', 'true');
  const backCover = latest && latest.photos[1] ? `<img src="${latest.photos[1].url}" alt="">` : '';
  const frontCover = latest && latest.photos[0] ? `<img src="${latest.photos[0].url}" alt="">` : '';
  visual.innerHTML = `
    <div class="book book-back ${backCover ? '' : 'placeholder'}">${backCover}</div>
    <div class="book book-front ${frontCover ? '' : 'placeholder'}">${frontCover}
      <div class="book-label"><span>${latest ? (latest.place || 'MEMORIAS') : 'MEMORIAS'}</span><strong>${latest ? latest.title : 'Tu primer photobook'}</strong></div>
    </div>
  `;
  hero.appendChild(visual);
  wrap.appendChild(hero);

  const libSection = el('section', 'section-block');
  const libHeading = el('div', 'section-heading', `<div><span class="section-kicker">Tu biblioteca</span><h2>Continúa donde lo dejaste</h2></div>`);
  const seeAll = el('button', 'text-button', 'Ver todos →');
  seeAll.addEventListener('click', () => { state.screen = 'library'; render(); });
  libHeading.appendChild(seeAll);
  libSection.appendChild(libHeading);

  if (state.photobooks.length) {
    const grid = el('div', 'album-grid home-grid');
    state.photobooks.slice(0, 3).forEach(b => grid.appendChild(AlbumCard(b)));
    libSection.appendChild(grid);
  } else {
    libSection.appendChild(emptyState('Aún no tienes photobooks', 'Sube tus primeras fotos y arma tu primer photobook.', 'Crear mi primer photobook', () => startCreate(TEMPLATES[0].id)));
  }
  wrap.appendChild(libSection);

  const recent = allRecentPhotos(4);
  if (recent.length) {
    const recentSection = el('section', 'section-block');
    recentSection.appendChild(el('div', 'section-heading', `<div><span class="section-kicker">Fotos recientes</span><h2>Lo último que subiste</h2></div>`));
    const strip = el('div', 'memory-strip');
    recent.forEach(p => {
      const card = el('button', 'memory-card', `<img src="${p.url}" alt=""><div class="memory-overlay"><small>${p.bookTitle}</small></div>`);
      card.addEventListener('click', () => { state.lightbox = { url: p.url, caption: p.bookTitle }; render(); });
      strip.appendChild(card);
    });
    recentSection.appendChild(strip);
    wrap.appendChild(recentSection);
  }
  return wrap;
}

function emptyState(title, desc, btnLabel, onClick) {
  const box = el('div', 'empty-state', `<strong>${title}</strong><p style="margin:0">${desc}</p>`);
  if (btnLabel) {
    const btn = el('button', 'primary-button', btnLabel);
    btn.addEventListener('click', onClick);
    box.appendChild(btn);
  }
  return box;
}

/* ============ MIS PHOTOBOOKS ============ */
function LibraryScreen() {
  const wrap = el('div', 'screen-stack');
  const titleRow = el('div', 'page-title-row', `<div><span class="section-kicker">Colección personal</span><h1>Mis photobooks</h1><p>Todos tus recuerdos, organizados en un solo lugar.</p></div>`);
  const newBtn = el('button', 'primary-button', '+ Crear photobook');
  newBtn.addEventListener('click', () => startCreate(TEMPLATES[0].id));
  titleRow.appendChild(newBtn);
  wrap.appendChild(titleRow);

  const toolbar = el('div', 'library-toolbar');
  const searchField = el('label', 'search-field', '⌕');
  const input = document.createElement('input');
  input.placeholder = 'Buscar por título o lugar...';
  input.value = state.search;
  input.addEventListener('input', e => { state.search = e.target.value; renderLibraryGridOnly(); });
  searchField.appendChild(input);
  toolbar.appendChild(searchField);
  wrap.appendChild(toolbar);

  const gridHolder = el('div');
  gridHolder.id = 'library-grid-holder';
  wrap.appendChild(gridHolder);
  setTimeout(renderLibraryGridOnly, 0);
  return wrap;
}

function renderLibraryGridOnly() {
  const holder = document.getElementById('library-grid-holder');
  if (!holder) return;
  const q = state.search.trim().toLowerCase();
  const filtered = state.photobooks.filter(b => !q || `${b.title} ${b.place} ${b.year}`.toLowerCase().includes(q));
  holder.innerHTML = '';
  if (!filtered.length) {
    holder.appendChild(emptyState(
      state.photobooks.length ? 'Sin resultados' : 'Aún no tienes photobooks',
      state.photobooks.length ? 'Prueba con otro término de búsqueda.' : 'Crea tu primer photobook subiendo algunas fotos.',
      state.photobooks.length ? null : 'Crear mi primer photobook',
      () => startCreate(TEMPLATES[0].id)
    ));
    return;
  }
  const grid = el('div', 'album-grid library-grid');
  filtered.forEach(b => grid.appendChild(AlbumCard(b)));
  holder.appendChild(grid);
}

function AlbumCard(book) {
  const cover = book.photos[0]
    ? `<img src="${book.photos[0].url}" alt="${book.title}">`
    : `<div class="cover-placeholder">${(book.title || '?')[0].toUpperCase()}</div>`;
  const card = el('button', 'album-card', `
    <div class="album-cover-wrap">${cover}<span class="album-year">${book.year || ''}</span><span class="album-count">${book.photos.length}</span></div>
    <div class="album-card-copy"><div><strong>${book.title}</strong><span>${book.place || (book.pages.length + ' páginas')}</span></div><span>⋯</span></div>
  `);
  card.addEventListener('click', () => { state.selectedBookId = book.id; state.screen = 'album'; render(); });
  return card;
}

/* ============ CREAR (INFO / FOTOS / DISEÑO) ============ */
function CreateScreen() {
  const d = state.draft;
  const layout = el('div', 'create-layout');
  const mainCol = el('div', 'create-main');

  const back = el('button', 'back-link', '← Volver');
  back.addEventListener('click', () => { state.draft = null; state.screen = state.editingBookId ? 'album' : 'home'; render(); });
  mainCol.appendChild(back);

  mainCol.appendChild(el('div', 'create-heading', `
    <span class="section-kicker">${state.editingBookId ? 'Editar photobook' : 'Nuevo proyecto'}</span>
    <h1>${state.editingBookId ? 'Ajusta tu historia.' : 'Crea una historia con tus mejores momentos.'}</h1>
    <p>Completa la información, sube tus fotos y diseña cada página.</p>
  `));

  const stepper = el('div', 'stepper');
  [[1, 'Información'], [2, 'Fotos'], [3, 'Diseño']].forEach(([n, label]) => {
    const b = el('button', state.createStep >= n ? 'done' : '', `<span>${n}</span><small>${label}</small>`);
    b.addEventListener('click', () => { state.createStep = n; state.armedSlot = null; render(); });
    stepper.appendChild(b);
  });
  mainCol.appendChild(stepper);

  if (state.createStep === 1) mainCol.appendChild(StepInfo(d));
  if (state.createStep === 2) mainCol.appendChild(StepPhotos(d));
  if (state.createStep === 3) mainCol.appendChild(StepDesign(d));

  const footer = el('div', 'create-footer');
  const prevBtn = el('button', 'secondary-button', '← Atrás');
  prevBtn.disabled = state.createStep === 1;
  prevBtn.addEventListener('click', () => { state.createStep = Math.max(1, state.createStep - 1); state.armedSlot = null; render(); });
  footer.appendChild(prevBtn);
  if (state.createStep < 3) {
    const nextBtn = el('button', 'primary-button', 'Continuar →');
    nextBtn.addEventListener('click', () => { state.createStep = Math.min(3, state.createStep + 1); state.armedSlot = null; render(); });
    footer.appendChild(nextBtn);
  } else {
    const saveBtn = el('button', 'primary-button', '✦ Guardar photobook');
    saveBtn.addEventListener('click', () => saveDraft(saveBtn));
    footer.appendChild(saveBtn);
  }
  mainCol.appendChild(footer);
  layout.appendChild(mainCol);
  layout.appendChild(CreatePreviewPanel(d));
  return layout;
}

function StepInfo(d) {
  const panel = el('div', 'form-panel');
  panel.appendChild(fieldInput('Nombre del photobook', d.title, v => { d.title = v; refreshPreviewPanel(); }));
  const twoCol = el('div', 'two-col-fields');
  twoCol.appendChild(fieldInput('Lugar', d.place, v => { d.place = v; refreshPreviewPanel(); }, 'Ej. Quito, Ecuador'));
  twoCol.appendChild(fieldInput('Año', d.year, v => { d.year = v; refreshPreviewPanel(); }, '2026'));
  panel.appendChild(twoCol);
  const tg = el('div', 'field-group');
  tg.appendChild(el('label', null, 'Descripción'));
  const ta = document.createElement('textarea');
  ta.placeholder = 'Cuenta brevemente la historia detrás de este photobook...';
  ta.value = d.description;
  ta.addEventListener('input', e => d.description = e.target.value);
  tg.appendChild(ta);
  panel.appendChild(tg);
  return panel;
}

function fieldInput(label, value, onInput, placeholder) {
  const fg = el('div', 'field-group');
  fg.appendChild(el('label', null, label));
  const input = document.createElement('input');
  input.value = value; if (placeholder) input.placeholder = placeholder;
  input.addEventListener('input', e => onInput(e.target.value));
  fg.appendChild(input);
  return fg;
}

function refreshPreviewPanel() {
  const holder = document.getElementById('create-preview-holder');
  if (!holder) return;
  holder.innerHTML = '';
  holder.appendChild(CreatePreviewPanel(state.draft, true));
}

function StepPhotos(d) {
  const wrap = el('div');
  const panel = el('div', 'upload-panel', `
    <div class="upload-icon">⇧</div>
    <h3>Arrastra tus fotos aquí</h3>
    <p>o selecciona archivos desde tu dispositivo</p>
  `);
  const selectBtn = el('button', 'secondary-button', 'Seleccionar imágenes');
  const fileInput = document.createElement('input');
  fileInput.type = 'file'; fileInput.accept = 'image/*'; fileInput.multiple = true; fileInput.style.display = 'none';
  fileInput.addEventListener('change', e => { readFilesToDraft(e.target.files); fileInput.value = ''; });
  selectBtn.addEventListener('click', () => fileInput.click());
  panel.appendChild(selectBtn);
  panel.appendChild(fileInput);
  panel.appendChild(el('small', null, 'JPG, PNG o WEBP'));
  panel.addEventListener('dragover', e => e.preventDefault());
  panel.addEventListener('drop', e => { e.preventDefault(); if (e.dataTransfer.files.length) readFilesToDraft(e.dataTransfer.files); });
  wrap.appendChild(panel);

  if (d.photos.length) {
    const strip = el('div', 'photo-strip');
    d.photos.forEach(p => {
      const thumb = el('div', 'p-thumb', `<img src="${p.url}" alt=""><button class="rm">×</button>`);
      thumb.querySelector('.rm').addEventListener('click', () => {
        removeDraftPhoto(p.id);
        render();
      });
      strip.appendChild(thumb);
    });
    wrap.appendChild(strip);
  } else {
    wrap.appendChild(el('p', 'editor-hint-text', 'Aún no subes fotos para este photobook.'));
  }
  return wrap;
}

function StepDesign(d) {
  const shell = el('div', 'editor-shell');
  shell.appendChild(el('p', 'editor-hint-text', 'Elige un diseño para esta página y luego arrastra una foto de tu galería —o haz clic en un espacio y luego en la foto— para colocarla.'));

  const page = d.pages[d._currentPageIdx ?? (d._currentPageIdx = 0)];

  const picker = el('div', 'layout-picker-row');
  Object.entries(LAYOUTS).forEach(([key, l]) => {
    const btn = el('button', 'layout-opt' + (page.layout === key ? ' active' : ''));
    btn.title = l.label;
    if (key === 'single') { btn.style.gridTemplateColumns = '1fr'; btn.innerHTML = '<div></div>'; }
    if (key === 'duoH') { btn.style.gridTemplateColumns = '1fr 1fr'; btn.innerHTML = '<div></div><div></div>'; }
    if (key === 'duoV') { btn.style.gridTemplateColumns = '1fr'; btn.style.gridTemplateRows = '1fr 1fr'; btn.innerHTML = '<div></div><div></div>'; }
    if (key === 'trio') { btn.style.gridTemplateColumns = '1fr 1fr'; btn.style.gridTemplateRows = '1fr 1fr'; btn.innerHTML = '<div style="grid-row:1/3"></div><div></div><div></div>'; }
    if (key === 'quad') { btn.style.gridTemplateColumns = '1fr 1fr'; btn.style.gridTemplateRows = '1fr 1fr'; btn.innerHTML = '<div></div><div></div><div></div><div></div>'; }
    btn.addEventListener('click', () => {
      const oldSlots = page.slots;
      const newSlots = new Array(l.slots).fill(null);
      for (let i = 0; i < Math.min(l.slots, oldSlots.length); i++) newSlots[i] = oldSlots[i];
      page.layout = key; page.slots = newSlots; state.armedSlot = null;
      render();
    });
    picker.appendChild(btn);
  });
  shell.appendChild(picker);

  const canvasWrap = el('div', 'editor-canvas-wrap');
  const canvas = el('div', 'editor-canvas ' + LAYOUTS[page.layout].cls);
  page.slots.forEach((photoId, idx) => {
    const photo = d.photos.find(p => p.id === photoId);
    const slot = el('div', 'editor-slot' + (state.armedSlot === idx ? ' armed' : ''));
    if (photo) {
      slot.innerHTML = `<img src="${photo.url}" alt=""><button class="clear">×</button>`;
      slot.querySelector('.clear').addEventListener('click', ev => { ev.stopPropagation(); page.slots[idx] = null; render(); });
    } else {
      slot.innerHTML = `<span class="hint">Clic o arrastra<br>una foto</span>`;
    }
    slot.addEventListener('click', () => {
      if (photo) return;
      state.armedSlot = state.armedSlot === idx ? null : idx;
      render();
    });
    slot.addEventListener('dragover', e => { e.preventDefault(); slot.classList.add('drag-over'); });
    slot.addEventListener('dragleave', () => slot.classList.remove('drag-over'));
    slot.addEventListener('drop', e => {
      e.preventDefault(); slot.classList.remove('drag-over');
      const pid = e.dataTransfer.getData('text/photo-id');
      if (pid) { page.slots[idx] = pid; state.armedSlot = null; render(); }
    });
    canvas.appendChild(slot);
  });
  canvasWrap.appendChild(canvas);
  shell.appendChild(canvasWrap);

  if (d.photos.length) {
    const gallery = el('div', 'photo-strip');
    d.photos.forEach(p => {
      const thumb = el('div', 'p-thumb', `<img src="${p.url}" alt="">`);
      thumb.draggable = true;
      thumb.addEventListener('dragstart', e => e.dataTransfer.setData('text/photo-id', p.id));
      thumb.addEventListener('click', () => {
        if (state.armedSlot !== null) { page.slots[state.armedSlot] = p.id; state.armedSlot = null; render(); }
      });
      gallery.appendChild(thumb);
    });
    shell.appendChild(gallery);
  } else {
    shell.appendChild(el('p', 'editor-hint-text', 'Sube fotos en el paso anterior para poder colocarlas aquí.'));
  }

  const strip = el('div', 'pages-strip');
  d.pages.forEach((pg, idx) => {
    const mini = el('div', 'page-mini' + (idx === (d._currentPageIdx) ? ' active' : ''));
    pg.slots.forEach(pid => {
      const photo = d.photos.find(p => p.id === pid);
      mini.appendChild(el('div', 'mini-slot', photo ? `<img src="${photo.url}" alt="">` : ''));
    });
    if (d.pages.length > 1) {
      const del = el('button', 'del', '×');
      del.addEventListener('click', ev => {
        ev.stopPropagation();
        d.pages.splice(idx, 1);
        if (d._currentPageIdx >= d.pages.length) d._currentPageIdx = d.pages.length - 1;
        state.armedSlot = null; render();
      });
      mini.appendChild(del);
    }
    mini.addEventListener('click', () => { d._currentPageIdx = idx; state.armedSlot = null; render(); });
    strip.appendChild(mini);
  });
  const addBtn = el('button', 'add-page-mini', '+');
  addBtn.addEventListener('click', () => { d.pages.push(newPage('single')); d._currentPageIdx = d.pages.length - 1; render(); });
  strip.appendChild(addBtn);
  shell.appendChild(strip);
  return shell;
}

function CreatePreviewPanel(d, skipId) {
  const panel = el('aside', 'create-preview-panel');
  if (!skipId) panel.id = 'create-preview-holder';
  panel.appendChild(el('span', 'preview-label', 'Vista previa'));
  const cover = d.photos[0] ? `<img src="${d.photos[0].url}" alt="">` : '';
  const mini = el('div', 'mini-book-preview', `
    ${cover}
    <div class="mini-book-copy"><small>MEMORIAS · ${d.year || ''}</small><strong>${d.title || 'Mi photobook'}</strong><span>${d.place || 'Una colección de momentos para volver a sentir.'}</span></div>
  `);
  panel.appendChild(mini);
  panel.appendChild(el('div', 'preview-hint', '<span>✦</span><p>La portada se actualiza con la primera foto que subas.</p>'));
  return panel;
}

/* ============ PLANTILLAS ============ */
function TemplatesScreen() {
  const wrap = el('div', 'screen-stack');
  wrap.appendChild(el('div', 'page-title-row', `<div><span class="section-kicker">Inspírate</span><h1>Plantillas</h1><p>Elige un punto de partida y personalízalo a tu manera.</p></div>`));
  const gallery = el('div', 'template-gallery');
  TEMPLATES.forEach(t => {
    const card = el('article', 'template-card');
    const l = LAYOUTS[t.defaultLayout];
    const img = el('div', 'template-image');
    if (t.badge) img.appendChild(el('span', 'badge', t.badge));
    const grid = document.createElement('div');
    grid.className = 'tpl-fill ' + l.cls;
    for (let i = 0; i < l.slots; i++) {
      const art = t.art[i % t.art.length];
      grid.appendChild(el('div', 'tpl-fill-slot', `<img src="${SAMPLE_ART[art]}" alt="">`));
    }
    img.appendChild(grid);
    img.appendChild(el('span', 'example-tag', 'Ejemplo'));
    const useBtn = el('button', null, 'Usar plantilla');
    useBtn.addEventListener('click', () => startCreate(t.id));
    img.appendChild(useBtn);
    card.appendChild(img);
    card.appendChild(el('div', null, `<strong>${t.name}</strong><p>${t.desc}</p>`));
    gallery.appendChild(card);
  });
  wrap.appendChild(gallery);
  return wrap;
}

/* ============ ÁLBUM (DETALLE) ============ */
function AlbumScreen() {
  const book = state.photobooks.find(b => b.id === state.selectedBookId);
  if (!book) {
    const wrap = el('div', 'screen-stack');
    wrap.appendChild(emptyState('Photobook no encontrado', 'Puede que haya sido eliminado.', 'Ir a mis photobooks', () => { state.screen = 'library'; render(); }));
    return wrap;
  }
  const wrap = el('div', 'screen-stack');
  const back = el('button', 'back-link', '← Mis photobooks');
  back.addEventListener('click', () => { state.screen = 'library'; render(); });
  wrap.appendChild(back);

  const hero = el('section', 'album-hero');
  const coverImg = book.photos[0] ? `<img src="${book.photos[0].url}" alt="${book.title}">` : `<div class="cover-placeholder">${book.title[0].toUpperCase()}</div>`;
  hero.appendChild(el('div', 'album-hero-cover', coverImg));
  const daysAgo = Math.max(0, Math.floor((Date.now() - new Date(book.createdAt).getTime()) / 86400000));
  const copy = el('div', 'album-hero-copy', `
    <span class="section-kicker">Photobook${book.year ? ' · ' + book.year : ''}</span>
    <h1>${book.title}</h1>
    <p>${book.description || book.place || 'Sin descripción todavía.'}</p>
    <div class="album-meta-row">
      <span>🖼 ${book.photos.length} fotos</span>
      <span>▤ ${book.pages.length} páginas</span>
      <span>🕒 ${daysAgo === 0 ? 'creado hoy' : 'creado hace ' + daysAgo + ' día' + (daysAgo === 1 ? '' : 's')}</span>
    </div>
  `);
  const actions = el('div', 'hero-actions');
  const viewBtn = el('button', 'primary-button', '▶ Ver photobook');
  viewBtn.addEventListener('click', () => { state.previewPage = 0; state.screen = 'preview'; render(); });
  const editBtn = el('button', 'secondary-button', '✎ Editar');
  editBtn.addEventListener('click', () => startEdit(book.id));
  const exportBtn = el('button', 'secondary-button export-pdf-btn', '⇩ Exportar PDF');
  exportBtn.addEventListener('click', () => exportBookToPdf(book));
  actions.appendChild(viewBtn); actions.appendChild(editBtn); actions.appendChild(exportBtn);
  copy.appendChild(actions);
  hero.appendChild(copy);
  wrap.appendChild(hero);

  const section = el('section', 'section-block');
  const heading = el('div', 'section-heading', `<div><span class="section-kicker">Fotos</span><h2>Todo lo que subiste</h2></div>`);
  const delBtn = el('button', 'text-button', 'Eliminar photobook');
  delBtn.style.color = '#a94f31';
  delBtn.addEventListener('click', () => deleteBook(book.id));
  heading.appendChild(delBtn);
  section.appendChild(heading);

  if (book.photos.length) {
    const grid = el('div', 'masonry-grid');
    book.photos.forEach((p, idx) => {
      const item = el('button', 'masonry-item item-' + ((idx % 4) + 1), `<img src="${p.url}" alt="">`);
      item.addEventListener('click', () => { state.lightbox = { url: p.url, caption: book.title }; render(); });
      grid.appendChild(item);
    });
    section.appendChild(grid);
  } else {
    section.appendChild(emptyState('Sin fotos todavía', 'Edita este photobook para subir tus fotos.', 'Editar photobook', () => startEdit(book.id)));
  }
  wrap.appendChild(section);
  return wrap;
}

/* ============ VISTA (PASAR PÁGINAS) ============ */
function PreviewScreen() {
  const book = state.photobooks.find(b => b.id === state.selectedBookId);
  if (!book) { state.screen = 'library'; return LibraryScreen(); }
  const pages = [{ type: 'cover' }, ...book.pages.map(p => ({ type: 'design', page: p }))];
  const idx = Math.min(state.previewPage, pages.length - 1);
  const current = pages[idx];

  const wrap = el('div', 'preview-screen');
  const topline = el('div', 'preview-topline');
  const back = el('button', 'back-link', '← Volver al álbum');
  back.addEventListener('click', () => { state.screen = 'album'; render(); });
  const actions = el('div');
  const exportBtn = el('button', 'secondary-button compact export-pdf-btn', '⇩ Exportar PDF');
  exportBtn.addEventListener('click', () => exportBookToPdf(book));
  actions.appendChild(exportBtn);
  topline.appendChild(back); topline.appendChild(actions);
  wrap.appendChild(topline);

  const stage = el('div', 'book-stage');
  const leftBtn = el('button', 'page-nav left', '‹');
  leftBtn.disabled = idx === 0;
  leftBtn.addEventListener('click', () => { state.previewPage = Math.max(0, idx - 1); render(); });

  const digital = el('div', 'digital-page ' + current.type);
  digital.id = 'preview-page-render';
  if (current.type === 'cover') {
    if (book.photos[0]) digital.innerHTML = `<img src="${book.photos[0].url}" alt="">`;
    else digital.innerHTML = `<div class="cover-placeholder">${book.title[0].toUpperCase()}</div>`;
    digital.innerHTML += `<div class="cover-overlay"><small>MEMORIAS ${book.year ? '· ' + book.year : ''}</small><h1>${book.title}</h1><p>${book.place || ''}</p></div>`;
  } else {
    digital.appendChild(buildDesignGrid(current.page, book.photos));
  }

  const rightBtn = el('button', 'page-nav right', '›');
  rightBtn.disabled = idx === pages.length - 1;
  rightBtn.addEventListener('click', () => { state.previewPage = Math.min(pages.length - 1, idx + 1); render(); });

  stage.appendChild(leftBtn); stage.appendChild(digital); stage.appendChild(rightBtn);
  wrap.appendChild(stage);

  const indicator = el('div', 'page-indicator');
  const left = el('span', null, String(idx + 1).padStart(2, '0'));
  const dots = el('div');
  pages.forEach((_, i) => {
    const dot = el('button', i === idx ? 'active' : '');
    dot.addEventListener('click', () => { state.previewPage = i; render(); });
    dots.appendChild(dot);
  });
  const right = el('span', null, String(pages.length).padStart(2, '0'));
  indicator.appendChild(left); indicator.appendChild(dots); indicator.appendChild(right);
  wrap.appendChild(indicator);
  return wrap;
}

function buildDesignGrid(page, photos) {
  const grid = el('div', 'page-design-grid ' + (LAYOUTS[page.layout] || LAYOUTS.single).cls);
  page.slots.forEach(pid => {
    const photo = photos.find(p => p.id === pid);
    grid.appendChild(el('div', 'd-slot', photo ? `<img src="${photo.url}" alt="">` : ''));
  });
  return grid;
}

/* ============ PERFIL ============ */
function ProfileScreen() {
  const wrap = el('div', 'screen-stack');
  wrap.appendChild(el('div', 'page-title-row', `<div><span class="section-kicker">Cuenta</span><h1>Mi perfil</h1><p>Información de tu cuenta en memora.</p></div>`));
  const layout = el('div', 'profile-layout');

  const displayName = (state.user.name || state.user.email.split('@')[0]);
  const initials = displayName.trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase() || '?';
  const panel = el('section', 'profile-panel');
  panel.appendChild(el('div', 'large-avatar', initials));
  panel.appendChild(el('div', null, `<h2 style="margin:6px 0 2px;">${displayName}</h2><p style="margin:0 0 6px;color:var(--muted);">${state.user.email}</p>`));
  const logoutBtn = el('button', 'secondary-button', 'Cerrar sesión');
  logoutBtn.addEventListener('click', logout);
  panel.appendChild(logoutBtn);
  layout.appendChild(panel);

  const settings = el('section', 'settings-panel');
  settings.appendChild(el('h3', null, 'Preferencias de exportación'));
  const row = el('div', 'setting-row', `<div><strong>Alta calidad al exportar PDF</strong><span>Genera páginas más nítidas; el archivo pesa más y tarda un poco más.</span></div>`);
  const sw = el('button', 'switch' + (state.profile.highQuality ? ' on' : ''), '<span></span>');
  sw.addEventListener('click', () => { state.profile.highQuality = !state.profile.highQuality; render(); });
  row.appendChild(sw);
  settings.appendChild(row);
  layout.appendChild(settings);

  wrap.appendChild(layout);
  return wrap;
}

/* ============ LIGHTBOX ============ */
function buildLightbox() {
  const backdrop = el('div', 'modal-backdrop');
  backdrop.addEventListener('click', () => { state.lightbox = null; render(); });
  const box = el('div', 'lightbox');
  box.addEventListener('click', e => e.stopPropagation());
  const close = el('button', 'modal-close', '×');
  close.addEventListener('click', () => { state.lightbox = null; render(); });
  box.appendChild(close);
  const img = el('img', null, '');
  img.src = state.lightbox.url;
  box.appendChild(img);
  box.appendChild(el('div', 'lightbox-caption', `<span>${state.lightbox.caption || ''}</span>`));
  backdrop.appendChild(box);
  return backdrop;
}

/* ============ EXPORTAR A PDF ============ */
async function exportBookToPdf(book) {
  try {
    if (typeof window.html2canvas !== 'function' || typeof window.jspdf === 'undefined') {
      showMessage('No se pudieron cargar las librerías necesarias para generar el PDF (html2canvas / jsPDF). Revisa tu conexión a internet e intenta de nuevo.');
      return;
    }
    if (!book.photos.length) {
      showMessage('Este photobook todavía no tiene fotos. Edítalo y sube al menos una foto antes de exportar.');
      return;
    }
    const btns = [...document.querySelectorAll('.export-pdf-btn')];
    btns.forEach(b => { b.disabled = true; b.dataset.originalLabel = b.textContent; b.textContent = 'Exportando…'; });
    toast('Generando PDF, un momento…');

    const holder = document.createElement('div');
    holder.style.position = 'fixed';
    holder.style.left = '-9999px';
    holder.style.top = '0';
    holder.style.width = '800px';
    holder.style.height = '800px';
    holder.style.background = '#fffdf8';
    document.body.appendChild(holder);

    try {
      const { jsPDF } = window.jspdf;
      const pdf = new jsPDF({ unit: 'mm', format: [210, 210] });
      const scale = state.profile.highQuality ? 2 : 1.2;

      const coverInner = book.photos[0]
        ? `<img src="${book.photos[0].url}" style="width:100%;height:100%;object-fit:cover;" crossorigin="anonymous">`
        : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#e9dfd2,#cdb89c);font:600 60px 'Playfair Display',serif;">${book.title[0].toUpperCase()}</div>`;
      holder.innerHTML = `<div style="position:relative;width:800px;height:800px;">${coverInner}
        <div style="position:absolute;inset:0;padding:60px;display:flex;flex-direction:column;justify-content:flex-end;color:#fff;background:linear-gradient(transparent 40%,rgba(18,14,10,.72));font-family:'DM Sans',sans-serif;">
          <small style="letter-spacing:.18em;font-size:13px;">MEMORIAS ${book.year ? '· ' + book.year : ''}</small>
          <h1 style="font:600 52px 'Playfair Display',serif;margin:10px 0;">${book.title}</h1>
          <p style="margin:0;font-size:16px;">${book.place || ''}</p>
        </div></div>`;
      await new Promise(r => setTimeout(r, 80));
      let canvas = await html2canvas(holder, { scale, backgroundColor: '#fffdf8', width: 800, height: 800, useCORS: true });
      pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, 210, 210);

      for (let i = 0; i < book.pages.length; i++) {
        const page = book.pages[i];
        let gridStyle = 'display:grid;gap:6px;padding:6px;width:800px;height:800px;';
        if (page.layout === 'single') gridStyle += 'grid-template-columns:1fr;';
        if (page.layout === 'duoH') gridStyle += 'grid-template-columns:1fr 1fr;';
        if (page.layout === 'duoV') gridStyle += 'grid-template-columns:1fr;grid-template-rows:1fr 1fr;';
        if (page.layout === 'trio') gridStyle += 'grid-template-columns:2fr 1fr;grid-template-rows:1fr 1fr;';
        if (page.layout === 'quad') gridStyle += 'grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;';
        let slotsHtml = '';
        page.slots.forEach((pid, idx) => {
          const photo = book.photos.find(p => p.id === pid);
          const rowSpan = (page.layout === 'trio' && idx === 0) ? 'grid-row:1/3;' : '';
          slotsHtml += `<div style="background:#efe7dd;overflow:hidden;border-radius:3px;${rowSpan}">${photo ? `<img src="${photo.url}" style="width:100%;height:100%;object-fit:cover;" crossorigin="anonymous">` : ''}</div>`;
        });
        holder.innerHTML = `<div style="${gridStyle}">${slotsHtml}</div>`;
        await new Promise(r => setTimeout(r, 80));
        canvas = await html2canvas(holder, { scale, backgroundColor: '#fffdf8', width: 800, height: 800, useCORS: true });
        pdf.addPage([210, 210], 'p');
        pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, 210, 210);
      }

      pdf.save((book.title || 'mi-photobook').replace(/[^\w\- ]/g, '').trim() + '.pdf');
      toast('PDF exportado ✓');
    } catch (err) {
      console.error(err);
      showMessage('No se pudo exportar el PDF.\n\nDetalle técnico: ' + (err && err.message ? err.message : err));
    } finally {
      document.body.removeChild(holder);
      btns.forEach(b => { b.disabled = false; b.textContent = b.dataset.originalLabel || '⇩ Exportar PDF'; });
    }
  } catch (outerErr) {
    console.error(outerErr);
    showMessage('No se pudo iniciar la exportación.\n\nDetalle técnico: ' + (outerErr && outerErr.message ? outerErr.message : outerErr));
  }
}

boot();
