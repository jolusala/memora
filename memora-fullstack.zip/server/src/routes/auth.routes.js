const express = require('express');
const bcrypt = require('bcryptjs');
const passport = require('../auth/passport');
const { pool } = require('../db');
const { signToken, verifyToken } = require('../auth/jwt');

const router = express.Router();

const GOOGLE_ENABLED = !!(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);

const COOKIE_OPTS = {
  httpOnly: true,
  sameSite: 'lax',
  secure: process.env.NODE_ENV === 'production',
  maxAge: 30 * 24 * 60 * 60 * 1000,
};

function publicUser(u) {
  return { id: u.id, email: u.email, name: u.name || '' };
}

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Falta email o contraseña' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
  }
  try {
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'Ya existe una cuenta con ese email' });
    }
    const hash = await bcrypt.hash(password, 10);
    const { rows } = await pool.query(
      'INSERT INTO users (email, password_hash, name) VALUES ($1, $2, $3) RETURNING *',
      [email.toLowerCase().trim(), hash, (name || '').trim()]
    );
    const user = rows[0];
    res.cookie('memora_token', signToken(user), COOKIE_OPTS);
    res.json({ user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al crear la cuenta' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Falta email o contraseña' });
  }
  try {
    const { rows } = await pool.query('SELECT * FROM users WHERE email = $1', [email.toLowerCase().trim()]);
    const user = rows[0];
    if (!user || !user.password_hash) {
      return res.status(401).json({ error: 'Email o contraseña incorrectos' });
    }
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: 'Email o contraseña incorrectos' });
    }
    res.cookie('memora_token', signToken(user), COOKIE_OPTS);
    res.json({ user: publicUser(user) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al iniciar sesión' });
  }
});

router.post('/logout', (req, res) => {
  res.clearCookie('memora_token');
  res.json({ ok: true });
});

router.get('/me', (req, res) => {
  const token = req.cookies && req.cookies.memora_token;
  if (!token) return res.status(401).json({ error: 'No autenticado' });
  try {
    const payload = verifyToken(token);
    res.json({ user: { id: payload.sub, email: payload.email, name: payload.name } });
  } catch (e) {
    res.status(401).json({ error: 'Sesión inválida o vencida' });
  }
});

if (GOOGLE_ENABLED) {
  router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'], session: false }));

  router.get(
    '/google/callback',
    passport.authenticate('google', { session: false, failureRedirect: '/?login_error=1' }),
    (req, res) => {
      res.cookie('memora_token', signToken(req.user), COOKIE_OPTS);
      res.redirect('/');
    }
  );
} else {
  router.get('/google', (req, res) => {
    res.status(503).json({ error: 'El login con Google no está configurado en este servidor todavía' });
  });
}

module.exports = router;
