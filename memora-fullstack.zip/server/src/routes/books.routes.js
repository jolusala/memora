const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { pool } = require('../db');
const requireAuth = require('../middleware/requireAuth');

const router = express.Router();
router.use(requireAuth);

const UPLOAD_ROOT = process.env.UPLOAD_DIR || path.join(__dirname, '..', '..', 'data', 'uploads');

function bookUploadDir(bookId) {
  const dir = path.join(UPLOAD_ROOT, String(bookId));
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, bookUploadDir(req.params.id)),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase() || '.jpg';
    cb(null, Date.now() + '-' + Math.round(Math.random() * 1e9) + ext);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) return cb(new Error('Solo se permiten imágenes'));
    cb(null, true);
  },
});

async function loadOwnedBook(id, userId) {
  const { rows } = await pool.query('SELECT * FROM photobooks WHERE id = $1 AND user_id = $2', [id, userId]);
  if (!rows.length) {
    const err = new Error('Photobook no encontrado');
    err.status = 404;
    throw err;
  }
  return rows[0];
}

function serializePhoto(p) {
  return { id: p.id, url: `/uploads/${p.photobook_id}/${p.filename}` };
}

function serializeBook(b) {
  return {
    id: b.id,
    title: b.title,
    place: b.place,
    year: b.year,
    description: b.description,
    template: b.template,
    pages: b.pages,
    createdAt: b.created_at,
    updatedAt: b.updated_at,
    photos: (b.photos || []).map(serializePhoto),
  };
}

router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT b.*, COALESCE(json_agg(p.*) FILTER (WHERE p.id IS NOT NULL), '[]') AS photos
       FROM photobooks b
       LEFT JOIN photos p ON p.photobook_id = b.id
       WHERE b.user_id = $1
       GROUP BY b.id
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json({ books: rows.map(serializeBook) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al cargar tus photobooks' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { title, place, year, description, template, pages } = req.body || {};
    const { rows } = await pool.query(
      `INSERT INTO photobooks (user_id, title, place, year, description, template, pages)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [
        req.user.id,
        title || 'Mi photobook',
        place || '',
        year || '',
        description || '',
        template || 'editorial',
        JSON.stringify(pages || []),
      ]
    );
    res.json({ book: serializeBook({ ...rows[0], photos: [] }) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al crear el photobook' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const book = await loadOwnedBook(req.params.id, req.user.id);
    const { rows: photos } = await pool.query(
      'SELECT * FROM photos WHERE photobook_id = $1 ORDER BY id',
      [req.params.id]
    );
    res.json({ book: serializeBook({ ...book, photos }) });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    await loadOwnedBook(req.params.id, req.user.id);
    const { title, place, year, description, template, pages } = req.body || {};
    const { rows } = await pool.query(
      `UPDATE photobooks SET title=$1, place=$2, year=$3, description=$4, template=$5, pages=$6, updated_at=now()
       WHERE id=$7 RETURNING *`,
      [
        title || 'Mi photobook',
        place || '',
        year || '',
        description || '',
        template || 'editorial',
        JSON.stringify(pages || []),
        req.params.id,
      ]
    );
    const { rows: photos } = await pool.query(
      'SELECT * FROM photos WHERE photobook_id = $1 ORDER BY id',
      [req.params.id]
    );
    res.json({ book: serializeBook({ ...rows[0], photos }) });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await loadOwnedBook(req.params.id, req.user.id);
    await pool.query('DELETE FROM photobooks WHERE id = $1', [req.params.id]);
    fs.rm(bookUploadDir(req.params.id), { recursive: true, force: true }, () => {});
    res.json({ ok: true });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

router.post(
  '/:id/photos',
  async (req, res, next) => {
    try {
      await loadOwnedBook(req.params.id, req.user.id);
      next();
    } catch (err) {
      res.status(err.status || 500).json({ error: err.message });
    }
  },
  (req, res, next) => {
    upload.single('photo')(req, res, (err) => {
      if (err) return res.status(400).json({ error: err.message });
      next();
    });
  },
  async (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No se recibió ninguna imagen' });
    try {
      const { rows } = await pool.query(
        'INSERT INTO photos (photobook_id, filename) VALUES ($1, $2) RETURNING *',
        [req.params.id, req.file.filename]
      );
      res.json({ photo: serializePhoto(rows[0]) });
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Error al guardar la foto' });
    }
  }
);

router.delete('/:id/photos/:photoId', async (req, res) => {
  try {
    await loadOwnedBook(req.params.id, req.user.id);
    const { rows } = await pool.query(
      'SELECT * FROM photos WHERE id = $1 AND photobook_id = $2',
      [req.params.photoId, req.params.id]
    );
    if (rows.length) {
      fs.unlink(path.join(bookUploadDir(req.params.id), rows[0].filename), () => {});
    }
    await pool.query('DELETE FROM photos WHERE id = $1 AND photobook_id = $2', [req.params.photoId, req.params.id]);
    res.json({ ok: true });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

module.exports = router;
