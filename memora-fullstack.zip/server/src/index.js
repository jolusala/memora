require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const { pool, migrate } = require('./db');
const passport = require('./auth/passport');
const authRoutes = require('./routes/auth.routes');
const bookRoutes = require('./routes/books.routes');

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use(cookieParser());
app.use(passport.initialize());

if (process.env.CORS_ORIGIN) {
  app.use(cors({ origin: process.env.CORS_ORIGIN, credentials: true }));
}

const UPLOAD_ROOT = process.env.UPLOAD_DIR || path.join(__dirname, '..', 'data', 'uploads');
fs.mkdirSync(UPLOAD_ROOT, { recursive: true });
app.use('/uploads', express.static(UPLOAD_ROOT, { maxAge: '30d' }));

app.use('/api/auth', authRoutes);
app.use('/api/books', bookRoutes);

const CLIENT_DIR = path.join(__dirname, '..', '..', 'client');
app.use(express.static(CLIENT_DIR));
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/uploads/')) return res.status(404).end();
  res.sendFile(path.join(CLIENT_DIR, 'index.html'));
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

const PORT = process.env.PORT || 3000;

migrate()
  .then(() => {
    app.listen(PORT, () => console.log(`memora server escuchando en el puerto ${PORT}`));
  })
  .catch((err) => {
    console.error('No se pudo preparar la base de datos', err);
    process.exit(1);
  });

process.on('unhandledRejection', (err) => console.error('unhandledRejection', err));

module.exports = { app, pool };
