const { verifyToken } = require('../auth/jwt');

function requireAuth(req, res, next) {
  const token = req.cookies && req.cookies.memora_token;
  if (!token) return res.status(401).json({ error: 'No autenticado' });
  try {
    const payload = verifyToken(token);
    req.user = { id: payload.sub, email: payload.email, name: payload.name };
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Sesión inválida o vencida' });
  }
}

module.exports = requireAuth;
