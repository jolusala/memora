const jwt = require('jsonwebtoken');

const SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  console.warn('⚠️  JWT_SECRET no está definido — usando uno temporal inseguro. Configúralo en producción.');
}
const EFFECTIVE_SECRET = SECRET || 'inseguro-cambia-esto-en-produccion';

function signToken(user) {
  return jwt.sign(
    { sub: user.id, email: user.email, name: user.name || '' },
    EFFECTIVE_SECRET,
    { expiresIn: '30d' }
  );
}

function verifyToken(token) {
  return jwt.verify(token, EFFECTIVE_SECRET);
}

module.exports = { signToken, verifyToken };
