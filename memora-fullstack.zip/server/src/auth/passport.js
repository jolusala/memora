const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const { pool } = require('../db');

if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: process.env.GOOGLE_CALLBACK_URL,
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        const email = profile.emails && profile.emails[0] && profile.emails[0].value;
        const googleId = profile.id;
        const name = profile.displayName || (email ? email.split('@')[0] : 'Usuario');

        const existing = await pool.query(
          'SELECT * FROM users WHERE google_id = $1 OR email = $2',
          [googleId, email]
        );

        let user;
        if (existing.rows.length) {
          user = existing.rows[0];
          if (!user.google_id) {
            const updated = await pool.query(
              'UPDATE users SET google_id = $1 WHERE id = $2 RETURNING *',
              [googleId, user.id]
            );
            user = updated.rows[0];
          }
        } else {
          const inserted = await pool.query(
            'INSERT INTO users (email, google_id, name) VALUES ($1, $2, $3) RETURNING *',
            [email, googleId, name]
          );
          user = inserted.rows[0];
        }
        done(null, user);
      } catch (err) {
        done(err);
      }
    }
  ));
} else {
  console.warn('⚠️  GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET no configurados — el login con Google quedará deshabilitado.');
}

module.exports = passport;
